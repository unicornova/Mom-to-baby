import React from 'react'
import Layout from '../components/Layout/Layout'

const suggestedFood = () => {
  return (
    <Layout>
      <div className='container flex items-center justify-center w-full h-[90vh] text-3xl'>
        <h1>
          Comming soon
        </h1>
      </div>
    </Layout>
  )
}

export default suggestedFood